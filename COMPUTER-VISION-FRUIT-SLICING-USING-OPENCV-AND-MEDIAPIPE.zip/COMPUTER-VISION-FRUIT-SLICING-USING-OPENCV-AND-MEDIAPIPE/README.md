# Hand-Tracking Fruit Slicer 🖐️🍉

An interactive, real-time Fruit Ninja-style game built with Python, OpenCV, and MediaPipe. Use your bare hands via webcam to slice flying fruits and rack up points by moving your index finger quickly across the screen!

🚀 Features
Real-Time Hand Tracking: Powered by Google's MediaPipe library to track the index fingertip precisely.

Motion-Based Slicing Mechanic: Features velocity calculation—fruits are only sliced if your hand moves faster than a specific threshold (similar to actual swiping).

Dynamic Gameplay: Fruits spawn randomly at the bottom with randomized colors, speeds, and drifting trajectories.

On-Screen HUD: Includes a live score counter and a dynamic speed indicator showing whether your hand movement is fast enough to slice.

🛠️ Prerequisites & Dependencies
Make sure you have Python installed along with the required libraries. You can install them via pip:

Bash
pip install opencv-python mediapipe
Note: You will also need a working webcam connected to your computer.

📦 Getting Started
How to Play:

Allow webcam access when prompted.

Position your hand in front of the camera.

Move your index finger swiftly like a blade to slice the colored circles as they float upwards.

Press q on your keyboard at any time to quit the game.

⚙️ Code Configuration
You can easily tweak the gameplay difficulty inside the script variables:

slice_threshold = 25: Adjust this value to make slicing easier or harder (higher means you need to move faster).

max_num_hands=1: Change the number of hands detected simultaneously if you want multiplayer or dual-hand slicing.

📄 License
This project is open-source 
